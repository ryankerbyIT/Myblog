const swconf = {
  
    cacheName: 'chirpy-1727729233',resources: [
      '/assets/css/jekyll-theme-chirpy.css',
      '/',
      
        '/categories/',
      
        '/tags/',
      
        '/archives/',
      

      
      
    ],

    interceptor: {paths: [
        
      ],urlPrefixes: [
        
      ]
    },

    purge: false
  
};

